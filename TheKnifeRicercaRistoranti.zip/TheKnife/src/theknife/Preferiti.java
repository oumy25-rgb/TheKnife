/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package theknife;

/**
 *
 * @author HEW4K7Z2EA
 */
public class Preferiti {
    String nomeUtente;
    String nomeRistorante;

    public Preferiti(String nomeUtente, String nomeRistorante) {
        this.nomeUtente = nomeUtente;
        this.nomeRistorante = nomeRistorante;
    }

    public String getNomeUtente() {
        return nomeUtente;
    }

    public void setNomeUtente(String nomeUtente) {
        this.nomeUtente = nomeUtente;
    }

    public String getNomeRistorante() {
        return nomeRistorante;
    }

    public void setNomeRistorante(String nomeRistorante) {
        this.nomeRistorante = nomeRistorante;
    }
    
    
}
